hmLoadTopic({
hmKeywords:"events,events quench,quench events",
hmTitle:"Quench Events Tab",
hmDescription:"The Quench Events Tab provides a list of quench detection events recorded by the instrument with a timestamp of the initiation of each event. The complete state of the Model...",
hmPrevLink:"rampdown-events-tab.html",
hmNextLink:"support-tab.html",
hmParentLink:"index.html",
hmBreadCrumbs:"Feature Descriptions",
hmTitlePath:"Feature Descriptions > Quench Events Tab",
hmHeader:"<h1 class=\"p_Heading1\" style=\"page-break-after: avoid;\"><span class=\"f_Heading1\">Quench Events Tab<\/span><\/h1>\n\r",
hmBody:"<p class=\"p_Normal\">The Quench Events Tab provides a list of quench detection events recorded by the instrument with a timestamp of the initiation of each event. The complete state of the Model 430 is recorded at the initiation of each event and is provided in the text space to the right upon selection of an event from the list.<\/p>\n\r<p class=\"p_Normal\">&nbsp;<\/p>\n\r<p class=\"p_Normal\">Up to the last 100 quench events will be fetched from the instrument. The event list is automatically refreshed each time the Quench Events Tab is entered.<\/p>\n\r<p class=\"p_Normal\">&nbsp;<\/p>\n\r<p class=\"p_Normal\">AMI Technical Support Representatives may ask for the entire history saved to a text file that you may then forward as an email attachment.<\/p>\n\r<p class=\"p_Normal\">&nbsp;<\/p>\n\r<p class=\"p_Normal\" style=\"text-align: center;\"><img alt=\"quench-tab\" style=\"margin:0 auto 0 auto;width:45.0625rem;height:36.6250rem;border:none\" src=\".\/images\/quench-tab.png\"\/><\/p>\n\r<p class=\"p_Normal\">&nbsp;<\/p>\n\r<p class=\"p_Normal\">&nbsp;<\/p>\n\r<p class=\"p_Normal\">&nbsp;<\/p>\n\r"
})
