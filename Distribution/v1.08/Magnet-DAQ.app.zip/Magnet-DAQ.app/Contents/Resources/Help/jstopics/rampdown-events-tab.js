hmLoadTopic({
hmKeywords:"events,events rampdown,external rampdown,external rampdown events",
hmTitle:"Rampdown Events Tab",
hmDescription:"The Rampdown Events Tab provides a list of rampdown events recorded by the instrument with a timestamp of the initiation of each event. The complete state of the Model 430 is...",
hmPrevLink:"rampdown-tab.html",
hmNextLink:"quench-events-tab.html",
hmParentLink:"index.html",
hmBreadCrumbs:"Feature Descriptions",
hmTitlePath:"Feature Descriptions > Rampdown Events Tab",
hmHeader:"<h1 class=\"p_Heading1\" style=\"page-break-after: avoid;\"><span class=\"f_Heading1\">Rampdown Events Tab<\/span><\/h1>\n\r",
hmBody:"<p class=\"p_Normal\">The Rampdown Events Tab provides a list of rampdown events recorded by the instrument with a timestamp of the initiation of each event. The complete state of the Model 430 is recorded at the initiation of each event and is provided in the text space to the right upon selection of an event from the list.<\/p>\n\r<p class=\"p_Normal\">&nbsp;<\/p>\n\r<p class=\"p_Normal\">The event list is automatically refreshed each time the Rampdown Events Tab is entered.<\/p>\n\r<p class=\"p_Normal\">&nbsp;<\/p>\n\r<p class=\"p_Normal\" style=\"text-align: center;\"><img alt=\"rampdown-events\" style=\"margin:0 auto 0 auto;width:44.7500rem;height:36.5000rem;border:none\" src=\".\/images\/rampdown-events.png\"\/><\/p>\n\r<p class=\"p_Normal\" style=\"text-align: center;\">&nbsp;<\/p>\n\r<p class=\"p_Normal\" style=\"text-align: center;\">&nbsp;<\/p>\n\r<p class=\"p_Normal\">&nbsp;<\/p>\n\r"
})
