hmLoadTopic({
hmKeywords:"settings,support",
hmTitle:"Support Tab",
hmDescription:"The Support Tab provides fields for contacting an Authorized AMI Technical Support Representative, including a Magnet ID or Support Case # field (the magnet number is very...",
hmPrevLink:"quench-events-tab.html",
hmNextLink:"status-bar.html",
hmParentLink:"index.html",
hmBreadCrumbs:"Feature Descriptions",
hmTitlePath:"Feature Descriptions > Support Tab",
hmHeader:"<h1 class=\"p_Heading1\" style=\"page-break-after: avoid;\"><span class=\"f_Heading1\">Support Tab<\/span><\/h1>\n\r",
hmBody:"<p class=\"p_Normal\">The Support Tab provides fields for contacting an Authorized AMI Technical Support Representative, including a Magnet ID or Support Case # field (the magnet number is very useful here), a Notes area for the problem description, and the complete settings of the Model 430.<\/p>\n\r<p class=\"p_Normal\">&nbsp;<\/p>\n\r<p class=\"p_Normal\">You may choose the &quot;Send to AMI Technical Support&quot; button to compose an email in the default email application as configured on your computer, or you can copy the Model 430 settings to the clipboard and paste it into a message of your own composition.<\/p>\n\r<p class=\"p_Normal\">&nbsp;<\/p>\n\r<p class=\"p_Normal\">Providing this information to AMI Technical Support can serve to expedite a more detailed response.<\/p>\n\r<p class=\"p_Normal\">&nbsp;<\/p>\n\r<p class=\"p_Normal\" style=\"text-align: center;\"><img alt=\"support-tab\" style=\"margin:0 auto 0 auto;width:45.0625rem;height:36.6250rem;border:none\" src=\".\/images\/support-tab.png\"\/><\/p>\n\r<p class=\"p_Normal\" style=\"text-align: center;\">&nbsp;<\/p>\n\r<p class=\"p_Normal\" style=\"text-align: center;\">&nbsp;<\/p>\n\r<p class=\"p_Normal\" style=\"text-align: center;\">&nbsp;<\/p>\n\r"
})
