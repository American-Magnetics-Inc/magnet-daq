/*! 
* Enter the function/s you want to call after topics load in this file.
* Nothing in this file should be executed on loading! All execution is
* initiated with a single statement stored in the POSTLOAD_FUNC variable
* including any arguments. Example:
* myFunction("red","blue");
*/
